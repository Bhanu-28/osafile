/**************************************************************************************************\
 *** VEOS_Compiler.h
 ***
 *** VEOS frame header file for compiler specific definitions for the MSVC compiler.
 ***
 *** Copyright (c) 2018 by dSPACE GmbH, Paderborn, Germany.
 *** All Rights Reserved.
\**************************************************************************************************/

#ifndef VEOS_COMPILER_H
#define VEOS_COMPILER_H

#pragma section("VEOS_CAL", read, write)

/*------------------------------------------------------------------------------------------------*\
  DEFINES (OPT)
\*------------------------------------------------------------------------------------------------*/

#define VEOS_CAL    __declspec(allocate("VEOS_CAL")) volatile

#endif /* VEOS_COMPILER_H */
