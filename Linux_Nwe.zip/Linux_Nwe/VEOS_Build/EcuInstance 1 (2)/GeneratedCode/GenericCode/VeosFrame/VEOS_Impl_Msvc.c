/**************************************************************************************************\
 *** VEOS_Impl_Msvc.c
 ***
 *** VEOS frame hand-coded implementation part for Microsoft compilers.
 ***
 *** Copyright (c) 2021 by dSPACE GmbH, Paderborn, Germany.
 *** All Rights Reserved.
\**************************************************************************************************/

#ifndef VEOS_IMPL_MSVC_C
#define VEOS_IMPL_MSVC_C

 /*------------------------------------------------------------------------------------------------*\
   DEFINES (OPT)
 \*------------------------------------------------------------------------------------------------*/

 /*------------------------------------------------------------------------------------------------*\
   INCLUDES
 \*------------------------------------------------------------------------------------------------*/

#ifdef _DEBUG
#include <crtdbg.h>
#endif /* _DEBUG */

#include "VEOS.h"

#ifdef _MSC_VER
#pragma comment(lib, "uuid")
#pragma comment(lib, "kernel32")
#endif

 /*------------------------------------------------------------------------------------------------*\
   PARAMETERIZED MACROS
 \*------------------------------------------------------------------------------------------------*/

 /*------------------------------------------------------------------------------------------------*\
   TYPEDEFS
 \*------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------*\
  VARIABLE DECLARATIONS
\*------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------*\
  FUNCTION PROTOTYPES
\*------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------*\
  VARIABLE DEFINITIONS
\*------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------*\
  FUNCTION DEFINITIONS
\*------------------------------------------------------------------------------------------------*/

#ifdef _DEBUG
/**************************************************************************************************\
 *** FUNCTION:
 ***     VEOS_CrtReportError
 ***
 *** DESCRIPTION:
 ***     Hook function to suppress error dialogs from the MSVC CRT. The messages will be written to
 ***     the client log instead.
 ***
 *** PARAMETERS:
 ***     Type            Name               Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     int             crtErrorCode       The CRT error code (_CRT_ASSERT, _CRT_ERROR, _CRT_WARN).
 ***     char *          szMsg              The fully assembled report message.
 ***     int *           returnValue        The value indicating whether the debugger should be started
 ***                                        or execution should continue.
 ***
 *** RETURNS:
 ***     int
 ***           TRUE to signal, that no further error reporting should take place.
 ***           FALSE to signal, that the regular handler should be called.
\**************************************************************************************************/
static int VEOS_CrtReportError(int crtErrorCode, char *szMsg, int *returnValue)
{
    VEOS_MsgApi_SeverityType severity;

    /* Find message level */
    switch (crtErrorCode)
    {
        case _CRT_WARN:
        {
            severity = VEOS_MsgApi_SeverityType_Warning;
            break;
        }
        case _CRT_ASSERT:
        case _CRT_ERROR:
        {
            severity = VEOS_MsgApi_SeverityType_Error;
            break;
        }
        default:
        {
            severity = VEOS_MsgApi_SeverityType_Error;
            break;
        }
    }

    /* Report error message. */
    (void)VEOS_MsgApi_ShowMessage(severity, VEOS_TRUE, szMsg);

    if (VEOS_NULL != returnValue)
    {
        /* Do not attach a debugger */
        *returnValue = 0;
    }

    /* Stop execution */
    return VEOS_TRUE;
}
#endif /* _DEBUG */

/**************************************************************************************************\
 *** FUNCTION:
 ***     VEOS_Target_HandleDownload
 ***
 *** DESCRIPTION:
 ***     Target specific function for VEOS Frame to initialize the target or its run-time during
 ***     download phase.
 ***
 *** PARAMETERS:
 ***     Type            Name               Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     -/-
 ***
 *** RETURNS:
 ***     VEOS_ApiSuccessType    If no error occurs, VEOS_E_OK will be returned. If any error
 ***                            occurs, an error code will be the result. See VEOS_Types.h for
 ***                            details.
\**************************************************************************************************/
VEOS_ApiSuccessType VEOS_Target_HandleDownload(void)
{
#ifdef _DEBUG
    _CrtSetReportHook(VEOS_CrtReportError);
    _CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_DEBUG | _CRTDBG_MODE_FILE);
    _CrtSetReportMode(_CRT_ERROR, _CRTDBG_MODE_DEBUG | _CRTDBG_MODE_FILE);
    _CrtSetReportMode(_CRT_ASSERT, _CRTDBG_MODE_DEBUG | _CRTDBG_MODE_FILE);
    _CrtSetReportFile(_CRT_WARN, _CRTDBG_FILE_STDERR);
    _CrtSetReportFile(_CRT_ERROR, _CRTDBG_FILE_STDERR);
    _CrtSetReportFile(_CRT_ASSERT, _CRTDBG_FILE_STDERR);
#endif /* _DEBUG */

    return VEOS_E_OK;
}

#endif /* VEOS_IMPL_MSVC_C */

/*------------------------------------------------------------------------------------------------*\
  END OF FILE
\*------------------------------------------------------------------------------------------------*/

