/*
 * File: A_KL15.h
 *
 * Code generated for Simulink model 'A_KL15'.
 *
 * Model version                  : 1.114
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Mar 25 15:06:29 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Freescale->MPC5xx
 * Code generation objectives:
 *    1. RAM efficiency
 *    2. ROM efficiency
 *    3. Execution efficiency
 *    4. Safety precaution
 *    5. MISRA C:2012 guidelines
 *    6. Traceability
 *    7. Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_A_KL15_h_
#define RTW_HEADER_A_KL15_h_
#ifndef A_KL15_COMMON_INCLUDES_
# define A_KL15_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "Rte_A_KL15.h"
#endif                                 /* A_KL15_COMMON_INCLUDES_ */

#include "rt_defines.h"
#include "L1_wrapper.h"             /*Pravallika*/


/* Block signals and states (default storage) for system '<Root>' */
typedef struct tag_DW_A_KL15_T {
  uint16 CounteOf5Sec;                 /* '<S10>/Chart' */
  uint8 In1;                           /* '<S13>/In1' */
  uint8 is_active_c1_A_KL15;           /* '<S6>/Chart1' */
  uint8 is_c1_A_KL15;                  /* '<S6>/Chart1' */
  boolean In1_m;                       /* '<S12>/In1' */
} DW_A_KL15_T;

/* Zero-crossing (trigger) state */
typedef struct tag_PrevZCX_A_KL15_T {
  ZCSigState Triggered_Trig_ZCE;       /* '<S1>/Triggered' */
} PrevZCX_A_KL15_T;

/* Block signals and states (default storage) */
extern DW_A_KL15_T DW_A_KL15;

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  Code generation will declare the memory for
 * these signals and export their symbols.
 *
 */
extern uint16 P_Adc_Kl15Vtg_us;        /* '<Root>/Function Caller' */
extern uint16 P_Adc_Kl30Vtg_us;        /* '<Root>/Function Caller1' */
extern uint8 P_EvCan_IgnKeyPos_uc;     /* '<Root>/Signal Copy2' */
extern boolean P_EvCan_IgnKeyPosValFlg_b;/* '<Root>/Signal Copy4' */
extern boolean P_EvCan_Bcm2ValidCom_b; /* '<Root>/Signal Copy5' */
extern boolean A_Kl15_St_b;            /* '<S7>/Logical_Operator' */
extern boolean A_Kl15_StMsmtchFltL2_b; /* '<S5>/Switch' */
extern boolean P_EvCan_VcuHvPwrUp_b;   /* '<Root>/Signal Copy3' */
extern boolean P_EvCan_VcuChkSum2Valid_b;/* '<Root>/Function Caller2' */
extern boolean P_EvCan_Vcu2ValidCom_b; /* '<Root>/Signal Copy8' */
extern boolean P_EvCan_VcuHvPwrUpValFlg_b;/* '<Root>/Signal Copy6' */
extern boolean A_Kl15_OprnCyc_StsChng_b;/* '<S11>/In1' */
extern boolean A_Kl15_VcuOfHVOnFltL3_b;/* '<S10>/Chart' */

/* Exported data declaration */

/* Const memory section */
/* Declaration for custom storage class: Const */
extern const uint8 A_KL15_ACC;
extern const uint8 A_KL15_ERR;
extern const uint8 A_KL15_INV1;
extern const uint8 A_KL15_INV2;
extern const uint8 A_KL15_INV3;
extern const uint8 A_KL15_OFF;
extern const uint8 A_KL15_ON;
extern const uint8 A_KL15_START;

/* ConstVolatile memory section */
/* Declaration for custom storage class: ConstVolatile */
extern const volatile uint16 A_Kl15_OffThr_C;
extern const volatile uint16 A_Kl15_OnThr_C;
extern const volatile uint16 COUNTERTHR;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<Root>/Signal Copy' : Eliminate redundant signal conversion block
 * Block '<Root>/Signal Copy1' : Eliminate redundant signal conversion block
 * Block '<Root>/Signal Copy7' : Eliminate redundant signal conversion block
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'A_KL15'
 * '<S1>'   : 'A_KL15/A_KL15_STEP'
 * '<S2>'   : 'A_KL15/Model Info'
 * '<S3>'   : 'A_KL15/A_KL15_STEP/IgnKeyPos_Arbitration'
 * '<S4>'   : 'A_KL15/A_KL15_STEP/IgnKeyPos_Validity'
 * '<S5>'   : 'A_KL15/A_KL15_STEP/KL15_Mismatch_Fault'
 * '<S6>'   : 'A_KL15/A_KL15_STEP/Kl15_KL30_Comparision'
 * '<S7>'   : 'A_KL15/A_KL15_STEP/Kl15_Status'
 * '<S8>'   : 'A_KL15/A_KL15_STEP/Subsystem'
 * '<S9>'   : 'A_KL15/A_KL15_STEP/Subsystem3'
 * '<S10>'  : 'A_KL15/A_KL15_STEP/Subsystem5'
 * '<S11>'  : 'A_KL15/A_KL15_STEP/Triggered'
 * '<S12>'  : 'A_KL15/A_KL15_STEP/VCU_Vaild_Check_Subsystem'
 * '<S13>'  : 'A_KL15/A_KL15_STEP/IgnKeyPos_Validity/IG_Vaild_Check_Subsystem'
 * '<S14>'  : 'A_KL15/A_KL15_STEP/IgnKeyPos_Validity/Subsystem2'
 * '<S15>'  : 'A_KL15/A_KL15_STEP/Kl15_KL30_Comparision/Chart1'
 * '<S16>'  : 'A_KL15/A_KL15_STEP/Kl15_KL30_Comparision/Subsystem8'
 * '<S17>'  : 'A_KL15/A_KL15_STEP/Kl15_KL30_Comparision/Subsystem9'
 * '<S18>'  : 'A_KL15/A_KL15_STEP/Subsystem5/Chart'
 * '<S19>'  : 'A_KL15/A_KL15_STEP/Triggered/Simulink Function'
 */

/*-
 * Requirements for '<Root>': A_KL15
 */
#endif                                 /* RTW_HEADER_A_KL15_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
