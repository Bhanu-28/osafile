/*
 * File: A_KL15_data.c
 *
 * Code generated for Simulink model 'A_KL15'.
 *
 * Model version                  : 1.114
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Mar 25 15:06:29 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Freescale->MPC5xx
 * Code generation objectives:
 *    1. RAM efficiency
 *    2. ROM efficiency
 *    3. Execution efficiency
 *    4. Safety precaution
 *    5. MISRA C:2012 guidelines
 *    6. Traceability
 *    7. Debugging
 * Validation result: Not run
 */

#include "A_KL15.h"

/* Exported data definition */

/* Const memory section */
/* Definition for custom storage class: Const */
const uint8 A_KL15_ACC = 1U;
const uint8 A_KL15_ERR = 7U;
const uint8 A_KL15_INV1 = 4U;
const uint8 A_KL15_INV2 = 5U;
const uint8 A_KL15_INV3 = 6U;
const uint8 A_KL15_OFF = 0U;
const uint8 A_KL15_ON = 2U;
const uint8 A_KL15_START = 3U;

/* ConstVolatile memory section */
/* Definition for custom storage class: ConstVolatile */
const volatile uint16 A_Kl15_OffThr_C = 30U;
const volatile uint16 A_Kl15_OnThr_C = 90U;
const volatile uint16 COUNTERTHR = 500U;

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
