/*
 * File: A_KL15.c
 *
 * Code generated for Simulink model 'A_KL15'.
 *
 * Model version                  : 1.114
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Mar 25 15:06:29 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Freescale->MPC5xx
 * Code generation objectives:
 *    1. RAM efficiency
 *    2. ROM efficiency
 *    3. Execution efficiency
 *    4. Safety precaution
 *    5. MISRA C:2012 guidelines
 *    6. Traceability
 *    7. Debugging
 * Validation result: Not run
 */

#include "A_KL15.h"
//#include "Rte_Type.h"//dhanya

/* Named constants for Chart: '<S6>/Chart1' */
#define A_KL15_IN_KL15_OFF             ((uint8)1U)
#define A_KL15_IN_KL15_ON              ((uint8)2U)

/* Exported block signals */
uint16 P_Adc_Kl15Vtg_us;               /* '<Root>/Function Caller' */
uint16 P_Adc_Kl30Vtg_us;               /* '<Root>/Function Caller1' */
uint8 P_EvCan_IgnKeyPos_uc;            /* '<Root>/Signal Copy2' */
boolean P_EvCan_IgnKeyPosValFlg_b;     /* '<Root>/Signal Copy4' */
boolean P_EvCan_Bcm2ValidCom_b;        /* '<Root>/Signal Copy5' */
boolean A_Kl15_St_b;                   /* '<S7>/Logical_Operator' */
boolean A_Kl15_StMsmtchFltL2_b;        /* '<S5>/Switch' */
boolean P_EvCan_VcuHvPwrUp_b;          /* '<Root>/Signal Copy3' */
boolean P_EvCan_VcuChkSum2Valid_b;     /* '<Root>/Function Caller2' */
boolean P_EvCan_Vcu2ValidCom_b;        /* '<Root>/Signal Copy8' */
boolean P_EvCan_VcuHvPwrUpValFlg_b;    /* '<Root>/Signal Copy6' */
boolean A_Kl15_OprnCyc_StsChng_b;      /* '<S11>/In1' */
boolean A_Kl15_VcuOfHVOnFltL3_b;       /* '<S10>/Chart' */

/* Block signals and states (default storage) */
DW_A_KL15_T DW_A_KL15;

/* Previous zero-crossings (trigger) states */
PrevZCX_A_KL15_T PrevZCX_A_KL15;
static void A_KL_Dem_SetOperationCycleState(Dem_OperationCycleStateType
  OperationState);

/* Output and update for Simulink Function: '<S11>/Simulink Function' */
static void A_KL_Dem_SetOperationCycleState(Dem_OperationCycleStateType
  OperationState)
{
  UNUSED_PARAMETER(OperationState);
}

/* Model step function */
void A_KL15_Step(void)
{
  boolean rtb_b_adc_vtg_hi;
  boolean rtb_CAN_IgnKeyPos_BCM_Start;
  boolean rtb_b_adc_vtg_sts;
  sint32 tmp;
  Dem_OperationCycleStateType tmp_0;
  uint32 rtb_b_adc_vtg_hi_tmp;

  /* FunctionCaller: '<Root>/Function Caller' */
  Rte_Call_P_Adc_Get_kl15vltg_P_Adc_Get_kl15vltg(&P_Adc_Kl15Vtg_us);

  /* FunctionCaller: '<Root>/Function Caller1' */
  Rte_Call_P_Adc_Get_kl30vltg_P_Adc_Get_kl30vltg(&P_Adc_Kl30Vtg_us);

  /* Product: '<S16>/Multiply1' incorporates:
   *  Constant: '<S16>/Constant1'
   *  Product: '<S17>/Multiply'
   */

  rtb_b_adc_vtg_hi_tmp = ((uint32)P_Adc_Kl15Vtg_us) * 100U;

  /* RelationalOperator: '<S16>/Relational_Operator' incorporates:
   *  Constant: '<S6>/A_Kl15_OnThr_C'
   *  Product: '<S16>/Multiply1'
   *  Product: '<S16>/Product'
   */
  rtb_b_adc_vtg_hi = (rtb_b_adc_vtg_hi_tmp > (((uint32)P_Adc_Kl30Vtg_us) *
    ((uint32)A_Kl15_OnThr_C)));

  /* Chart: '<S6>/Chart1' incorporates:
   *  Constant: '<S6>/A_Kl15_OffThr_C'
   *  Product: '<S17>/Product1'
   *  RelationalOperator: '<S17>/Relational_Operator1'
   */
  if (((uint32)DW_A_KL15.is_active_c1_A_KL15) == 0U) {
    DW_A_KL15.is_active_c1_A_KL15 = 1U;
    if (rtb_b_adc_vtg_hi) {
      DW_A_KL15.is_c1_A_KL15 = A_KL15_IN_KL15_ON;
      rtb_b_adc_vtg_sts = true;
    } else {
      DW_A_KL15.is_c1_A_KL15 = A_KL15_IN_KL15_OFF;
      rtb_b_adc_vtg_sts = false;
    }
  } else if (((uint32)DW_A_KL15.is_c1_A_KL15) == A_KL15_IN_KL15_OFF) {
    rtb_b_adc_vtg_sts = false;
    if (rtb_b_adc_vtg_hi) {
      DW_A_KL15.is_c1_A_KL15 = A_KL15_IN_KL15_ON;
      rtb_b_adc_vtg_sts = true;
    }
  } else {
    rtb_b_adc_vtg_sts = true;
    if (rtb_b_adc_vtg_hi_tmp < (((uint32)P_Adc_Kl30Vtg_us) * ((uint32)
          A_Kl15_OffThr_C))) {
      DW_A_KL15.is_c1_A_KL15 = A_KL15_IN_KL15_OFF;
      rtb_b_adc_vtg_sts = false;
    }
  }

  /* End of Chart: '<S6>/Chart1' */

  /* SignalConversion: '<Root>/Signal Copy5' incorporates:
   *  Inport: '<Root>/P_EvCan_Bcm2ValidCom_b'
   */
  Rte_Read_P_EvCan_Bcm2ValidCom_b_P_EvCan_Bcm2ValidCom_b(&P_EvCan_Bcm2ValidCom_b);

  /* SignalConversion: '<Root>/Signal Copy4' incorporates:
   *  Inport: '<Root>/P_EvCan_IgnKeyPosValFlg_b'
   */
  Rte_Read_P_EvCan_IgnKeyPosValFlg_b_P_EvCan_IgnKeyPosValFlg_b
    (&P_EvCan_IgnKeyPosValFlg_b);

  /* SignalConversion: '<Root>/Signal Copy2' incorporates:
   *  Inport: '<Root>/P_EvCan_IgnKeyPos_uc'
   */
  Rte_Read_P_EvCan_IgnKeyPos_uc_P_EvCan_IgnKeyPos_uc(&P_EvCan_IgnKeyPos_uc);

  /* Outputs for Enabled SubSystem: '<S4>/IG_Vaild_Check_Subsystem' incorporates:
   *  EnablePort: '<S13>/Enable'
   */
  /* Logic: '<S14>/Logical_Operator_9' incorporates:
   *  Inport: '<S13>/In1'
   *  Logic: '<S14>/Logical_Operator4'
   *  RelationalOperator: '<S14>/Relational_Operator10'
   */
  if ((!P_EvCan_IgnKeyPosValFlg_b) && P_EvCan_Bcm2ValidCom_b) {
    DW_A_KL15.In1 = P_EvCan_IgnKeyPos_uc;
  }

  /* End of Logic: '<S14>/Logical_Operator_9' */
  /* End of Outputs for SubSystem: '<S4>/IG_Vaild_Check_Subsystem' */

  /* RelationalOperator: '<S3>/Relational_Operator3' incorporates:
   *  Constant: '<S3>/Constant4'
   */
  rtb_b_adc_vtg_hi = (DW_A_KL15.In1 == A_KL15_ON);

  /* RelationalOperator: '<S3>/Relational_Operator4' incorporates:
   *  Constant: '<S3>/Constant5'
   */
  rtb_CAN_IgnKeyPos_BCM_Start = (DW_A_KL15.In1 == A_KL15_START);

  /* Logic: '<S7>/Logical_Operator' */
  A_Kl15_St_b = ((rtb_b_adc_vtg_sts || rtb_b_adc_vtg_hi) ||
                 rtb_CAN_IgnKeyPos_BCM_Start);

  /* Outport: '<Root>/A_Kl15_St_b' incorporates:
   *  SignalConversion: '<Root>/Signal Copy9'
   */
  (void) Rte_Write_A_Kl15_St_b_A_Kl15_St_b(A_Kl15_St_b);

  /* Switch: '<S5>/Switch' incorporates:
   *  Constant: '<S5>/Constant1'
   */
  if (A_Kl15_St_b) {
    /* Switch: '<S5>/Switch1' incorporates:
     *  Constant: '<S3>/Constant10'
     *  Constant: '<S3>/Constant7'
     *  Constant: '<S3>/Constant8'
     *  Constant: '<S3>/Constant9'
     *  Constant: '<S5>/Constant'
     *  Logic: '<S3>/Logical Operator3'
     *  Logic: '<S5>/Logical Operator1'
     *  Logic: '<S5>/Logical Operator2'
     *  RelationalOperator: '<S3>/Relational Operator6'
     *  RelationalOperator: '<S3>/Relational Operator7'
     *  RelationalOperator: '<S3>/Relational Operator8'
     *  RelationalOperator: '<S3>/Relational Operator9'
     *  RelationalOperator: '<S5>/Relational Operator2'
     */
    if ((((DW_A_KL15.In1 == A_KL15_INV1) || (DW_A_KL15.In1 == A_KL15_INV2)) ||
         (DW_A_KL15.In1 == A_KL15_INV3)) || (DW_A_KL15.In1 == A_KL15_ERR)) {
      tmp = 0;
    } else {
      tmp = (((sint32)((rtb_b_adc_vtg_hi || rtb_CAN_IgnKeyPos_BCM_Start) ? 1 : 0))
             != ((sint32)(rtb_b_adc_vtg_sts ? 1 : 0)));
    }

    /* End of Switch: '<S5>/Switch1' */
    A_Kl15_StMsmtchFltL2_b = (tmp != 0);
  } else {
    A_Kl15_StMsmtchFltL2_b = false;
  }

  /* End of Switch: '<S5>/Switch' */

  /* SignalConversion: '<Root>/Signal Copy8' incorporates:
   *  Inport: '<Root>/P_EvCan_Vcu2ValidCom_b'
   */
  Rte_Read_P_EvCan_Vcu2ValidCom_b_P_EvCan_Vcu2ValidCom_b(&P_EvCan_Vcu2ValidCom_b);

  /* SignalConversion: '<Root>/Signal Copy6' incorporates:
   *  Inport: '<Root>/P_EvCan_VcuHvPwrUpValFlg_b'
   */
  Rte_Read_P_EvCan_VcuHvPwrUpValFlg_b_P_EvCan_VcuHvPwrUpValFlg_b
    (&P_EvCan_VcuHvPwrUpValFlg_b);

  /* SignalConversion: '<Root>/Signal Copy3' incorporates:
   *  Inport: '<Root>/P_EvCan_VcuHVPwrUp_b'
   */
  Rte_Read_P_EvCan_VcuHVPwrUp_b_P_EvCan_VcuHVPwrUp_b(&P_EvCan_VcuHvPwrUp_b);

  /* Outport: '<Root>/A_Kl15_StMsmtchFltL2_b' incorporates:
   *  SignalConversion: '<Root>/Signal Copy10'
   */
  (void) Rte_Write_A_Kl15_StMsmtchFltL2_b_A_Kl15_StMsmtchFltL2_b
    (A_Kl15_StMsmtchFltL2_b);

  /* FunctionCaller: '<Root>/Function Caller2' */
  Rte_Call_P_EvCan_Get_VcuChkSum2Valid_b_P_EvCan_Get_VcuChkSum2Valid_b
    (&P_EvCan_VcuChkSum2Valid_b);

  /* Outputs for Enabled SubSystem: '<S1>/VCU_Vaild_Check_Subsystem' incorporates:
   *  EnablePort: '<S12>/Enable'
   */
  /* Logic: '<S9>/not_2' incorporates:
   *  Inport: '<S12>/In1'
   *  Logic: '<S8>/Logical Operator4'
   *  Logic: '<S8>/Logical Operator5'
   *  Logic: '<S9>/Logical_Operator5'
   */
  if ((P_EvCan_VcuChkSum2Valid_b && P_EvCan_Vcu2ValidCom_b) &&
      (!P_EvCan_VcuHvPwrUpValFlg_b)) {
    DW_A_KL15.In1_m = P_EvCan_VcuHvPwrUp_b;
  }

  /* End of Logic: '<S9>/not_2' */
  /* End of Outputs for SubSystem: '<S1>/VCU_Vaild_Check_Subsystem' */

  /* Switch: '<S10>/Switch2' incorporates:
   *  Constant: '<S10>/Constant2'
   *  Constant: '<S3>/Constant12'
   *  Constant: '<S3>/Constant6'
   *  Logic: '<S10>/Logical Operator1'
   *  Logic: '<S10>/Logical_Operator8'
   *  RelationalOperator: '<S3>/Relational_Operator11'
   *  RelationalOperator: '<S3>/Relational_Operator5'
   */
  if (A_Kl15_St_b) {
    rtb_b_adc_vtg_hi = false;
  } else {
    rtb_b_adc_vtg_hi = ((DW_A_KL15.In1_m) && ((DW_A_KL15.In1 == A_KL15_OFF) ||
      (DW_A_KL15.In1 == A_KL15_ACC)));
  }

  /* End of Switch: '<S10>/Switch2' */

  /* Chart: '<S10>/Chart' incorporates:
   *  Constant: '<S10>/Constant'
   */
  if (rtb_b_adc_vtg_hi) {
    A_Kl15_VcuOfHVOnFltL3_b = false;
    DW_A_KL15.CounteOf5Sec = 0U;
  } else {
    rtb_b_adc_vtg_hi_tmp = ((uint32)DW_A_KL15.CounteOf5Sec) + 1U;
    if (rtb_b_adc_vtg_hi_tmp > 65535U) {
      rtb_b_adc_vtg_hi_tmp = 65535U;
    }

    DW_A_KL15.CounteOf5Sec = (uint16)rtb_b_adc_vtg_hi_tmp;
    if (DW_A_KL15.CounteOf5Sec > COUNTERTHR) {
      A_Kl15_VcuOfHVOnFltL3_b = true;
      DW_A_KL15.CounteOf5Sec = 0U;
    }
  }

  /* End of Chart: '<S10>/Chart' */

  /* Outport: '<Root>/A_Kl15_VcuOfHVOnFltL3_b' incorporates:
   *  SignalConversion: '<Root>/Signal Copy11'
   */
  (void) Rte_Write_A_Kl15_VcuOfHVOnFltL3_b_A_Kl15_VcuOfHVOnFltL3_b
    (A_Kl15_VcuOfHVOnFltL3_b);

  /* Outputs for Triggered SubSystem: '<S1>/Triggered' incorporates:
   *  TriggerPort: '<S11>/Trigger'
   */
  if ((((sint32)((((uint32)PrevZCX_A_KL15.Triggered_Trig_ZCE) == POS_ZCSIG) ? 1 :
                 0)) != ((sint32)(A_Kl15_St_b ? 1 : 0))) && (((uint32)
        PrevZCX_A_KL15.Triggered_Trig_ZCE) != UNINITIALIZED_ZCSIG)) {
    /* Inport: '<S11>/In1' */
    A_Kl15_OprnCyc_StsChng_b = A_Kl15_St_b;

    /* Switch: '<S11>/Switch' incorporates:
     *  Constant: '<S11>/Constant2'
     *  Constant: '<S11>/Constant4'
     */
    if (A_Kl15_OprnCyc_StsChng_b) {
      tmp_0 = DEM_CYCLE_STATE_START;
    } else {
      tmp_0 = DEM_CYCLE_STATE_END;
    }

    /* End of Switch: '<S11>/Switch' */

    /* FunctionCaller: '<S11>/Function Caller1' */
    A_KL_Dem_SetOperationCycleState(tmp_0);
  }

  PrevZCX_A_KL15.Triggered_Trig_ZCE = A_Kl15_St_b ? 1U : 0U;

  /* End of Outputs for SubSystem: '<S1>/Triggered' */

  /* Outport: '<Root>/A_Kl15_OprnCyc_StsChng_b' incorporates:
   *  SignalConversion: '<Root>/Signal Copy12'
   */
  (void) Rte_Write_A_Kl15_OprnCyc_StsChng_b_A_Kl15_OprnCyc_StsChng_b
    (A_Kl15_OprnCyc_StsChng_b);
}

/* Model initialize function */
void A_KL15_Init(void)
{
  PrevZCX_A_KL15.Triggered_Trig_ZCE = UNINITIALIZED_ZCSIG;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
