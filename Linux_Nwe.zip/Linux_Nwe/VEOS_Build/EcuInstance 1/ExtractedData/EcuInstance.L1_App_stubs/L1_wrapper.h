#ifndef L1_WRAPPER_H
#define L1_WRAPPER_H
/* Macros for accessing real-time model data structure */ /*Pravallika* Added line number 35,38,39 to resolve compilation error*/
typedef uint8 Dem_OperationCycleStateType;

 
#define DEM_CYCLE_STATE_START 0U
#define DEM_CYCLE_STATE_END 1U   

#endif