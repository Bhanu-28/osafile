#include "SmartServices_Cfg_generated.h"

#define VEOS_SFMC_SERVICE_BYP SMARTSERVICES_BYP