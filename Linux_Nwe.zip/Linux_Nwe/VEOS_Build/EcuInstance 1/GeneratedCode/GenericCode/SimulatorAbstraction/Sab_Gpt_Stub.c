/**************************************************************************************************\
 *** Sab_Gpt_Stub.c
 ***
 *** Implementation the general purpose timer for VEOS using the Windows API.
 ***
 *** Copyright (c) 2014 by dSPACE GmbH, Paderborn, Germany.
 *** All Rights Reserved.
\**************************************************************************************************/

#ifndef SAB_GPT_STUB_C
#define SAB_GPT_STUB_C

/*------------------------------------------------------------------------------------------------*\
  INCLUDES
\*------------------------------------------------------------------------------------------------*/

#include <time.h>

#include "Platform_Types.h"
#include "Std_Types.h"
#include "VEOS.h"

#include "Sab_Types.h"
#include "Sab_Cfg.h"
#include "Sab.h"

#if (SAB_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*------------------------------------------------------------------------------------------------*\
  PARAMETRIZED MACROS
\*------------------------------------------------------------------------------------------------*/

/* 4294967296 = 2^32 = 32 left shifts */
#define SAB_LARGEINT_TOLONGLONG(value) (((long long)value.HighPart) * 4294967296) + value.LowPart
#define SAB_LONGLONG_TOUINT32(value) (uint32)(value & 0xFFFFFFFF)

/*------------------------------------------------------------------------------------------------*\
  VARIABLE DECLARATIONS
\*------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------*\
  FUNCTION DEFINITIONS
\*------------------------------------------------------------------------------------------------*/

/**************************************************************************************************\
 *** FUNCTION:
 ***     Sab_Gpt_Init
 ***
 *** DESCRIPTION:
 ***     Starts the general purpose timer for the simulator abstraction hardware timer.
 ***
 *** PARAMETERS:
 ***     Type                  Name         Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     Sab_ApplicationState  state        Value of the unsupported application state entered.
 ***
 *** RETURNS:
 ***     void
\**************************************************************************************************/
void Sab_Gpt_Init(void)
{
}

/**************************************************************************************************\
 *** FUNCTION:
 ***     Sab_Gpt_DeInit
 ***
 *** DESCRIPTION:
 ***     Stops the general purpose timer for the simulator abstraction hardware timer.
 ***
 *** PARAMETERS:
 ***     Type                  Name         Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     -/-
 ***
 *** RETURNS:
 ***     void
\**************************************************************************************************/
void Sab_Gpt_DeInit(void)
{
}

/**************************************************************************************************\
 *** FUNCTION:
 ***     Sab_Gpt_GetCurrentHwCounter100ns
 ***
 *** DESCRIPTION:
 ***     Gets the current hardware timer. The underlying timer uses a resolution of 100 nano second and a
 ***     precision of 32 bit. Thus this timer will overflow after 429,4967296 seconds.
 ***
 *** PARAMETERS:
 ***     Type                               Name         Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     Sab_PredefTimer100ns32bitType      currentValue The value to set
 ***
 *** RETURNS:
 ***     boolean
 ***            TRUE    if the value has been obtained successfully.
 ***            FALSE   if an error has occurred.
\**************************************************************************************************/
boolean Sab_Gpt_GetCurrentHwCounter100ns(Sab_PredefTimer100ns32bitType *currentValue)
{
#if (SAB_HUNDRED_NANOSECONDPRECISION == STD_ON)
    /*  __int64 nsec_count, nsec_per_tick; */
    long long int nsec_count, nsec_per_tick;
    long long int nsec_per_sec = 1000000000;   /* 1/1ns  */
#endif

    if (NULL == currentValue)
    {
#if (SAB_DEV_ERROR_DETECT == STD_ON)
        Det_ReportError(SAB_MODULE_ID, 0, SAB_LOWLEVEL_TIMER_API, SAB_E_PARAM_POINTER);
#endif
        return FALSE;
    }

    currentValue->ReferenceTime = 0;
#if (SAB_HUNDRED_NANOSECONDPRECISION == STD_ON)

    /*
     * clock_gettime() returns the number of secs. We translate that to number of nanosecs.
     * clock_getres() returns number of seconds per tick. We translate that to number of nanosecs per tick.
     * Number of nanosecs divided by number of nanosecs per tick - will give the number of ticks.
     */
     struct timespec ts1, ts2;

     if (clock_gettime(CLOCK_MONOTONIC, &ts1) != 0) {
         VEOS_MsgApi_ShowMessageFormat(VEOS_MsgApi_SeverityType_Error, VEOS_TRUE, " API clock_gettime() fails");
         VEOS_SimApi_TerminateSimulation(VEOS_SimApi_TerminationKindType_StopSimulationAndFail);
         return FALSE;
     }

     nsec_count = ts1.tv_nsec + ts1.tv_sec * nsec_per_sec;

     if (clock_getres(CLOCK_MONOTONIC, &ts2) != 0) {
#if (SAB_DEV_ERROR_DETECT == STD_ON)
         Det_ReportError(SAB_MODULE_ID, 0, SAB_LOWLEVEL_TIMER_API, SAB_E_HARDWARE_TIMER);
#endif
         VEOS_MsgApi_ShowMessageFormat(VEOS_MsgApi_SeverityType_Error, VEOS_TRUE, " API clock_getres() fails");
         VEOS_SimApi_TerminateSimulation(VEOS_SimApi_TerminationKindType_StopSimulationAndFail);
         return FALSE;
     }

     nsec_per_tick = ts2.tv_nsec + ts2.tv_sec * nsec_per_sec;

     currentValue->ReferenceTime = (nsec_count / nsec_per_tick / 100);  /*  LSB=100ns  */

    return TRUE;
#else
#if (SAB_DEV_ERROR_DETECT == STD_ON)
    Det_ReportError(SAB_MODULE_ID, 0, SAB_LOWLEVEL_TIMER_API, SAB_E_NO_SERVICE);
#endif
    return FALSE;
#endif /* SAB_HUNDRED_NANOSECONDPRECISION == STD_ON */

}

/**************************************************************************************************\
 *** FUNCTION:
 ***     Sab_Gpt_GetCurrentHwCounter1ns
 ***
 *** DESCRIPTION:
 ***     Gets the current hardware timer. The underlying timer uses a resolution of 1 nano second and a
 ***     precision of 64 bit. Thus this timer will overflow after 18446744073,709551616 seconds.
 ***
 *** PARAMETERS:
 ***     Type                               Name         Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     Sab_PredefTimer1ns64bitType        currentValue The value to set
 ***
 *** RETURNS:
 ***     boolean
 ***            TRUE    if the value has been obtained successfully.
 ***            FALSE   if an error has occurred.
\**************************************************************************************************/
boolean Sab_Gpt_GetCurrentHwCounter1ns(Sab_PredefTimer1ns64bitType *currentValue)
{
#if (SAB_ONE_NANOSECONDPRECISION == STD_ON)
    /*  __int64 nsec_count, nsec_per_tick; */
    long long int nsec_count, nsec_per_tick;
    long long int nsec_per_sec = 1000000000;   /* 1/1ns  */
#endif

    if (NULL == currentValue)
    {
#if (SAB_DEV_ERROR_DETECT == STD_ON)
        Det_ReportError(SAB_MODULE_ID, 0, SAB_LOWLEVEL_TIMER_API, SAB_E_PARAM_POINTER);
#endif
        return FALSE;
    }

    currentValue->ReferenceTime = 0;

#if (SAB_ONE_NANOSECONDPRECISION == STD_ON)
    /*
     * clock_gettime() returns the number of secs. We translate that to number of nanosecs.
     * clock_getres() returns number of seconds per tick. We translate that to number of nanosecs per tick.
     * Number of nanosecs divided by number of nanosecs per tick - will give the number of ticks.
     */
     struct timespec ts1, ts2;

     if (clock_gettime(CLOCK_MONOTONIC, &ts1) != 0) {
         VEOS_MsgApi_ShowMessageFormat(VEOS_MsgApi_SeverityType_Error, VEOS_TRUE, " API clock_gettime() fails");
         VEOS_SimApi_TerminateSimulation(VEOS_SimApi_TerminationKindType_StopSimulationAndFail);
         return FALSE;
     }

     nsec_count = ts1.tv_nsec + ts1.tv_sec * nsec_per_sec;

     if (clock_getres(CLOCK_MONOTONIC, &ts2) != 0) {
#if (SAB_DEV_ERROR_DETECT == STD_ON)
         Det_ReportError(SAB_MODULE_ID, 0, SAB_LOWLEVEL_TIMER_API, SAB_E_HARDWARE_TIMER);
#endif
         VEOS_MsgApi_ShowMessageFormat(VEOS_MsgApi_SeverityType_Error, VEOS_TRUE, " API clock_getres() fails");
         VEOS_SimApi_TerminateSimulation(VEOS_SimApi_TerminationKindType_StopSimulationAndFail);
         return FALSE;
     }

     nsec_per_tick = ts2.tv_nsec + ts2.tv_sec * nsec_per_sec;

     currentValue->ReferenceTime = (nsec_count / nsec_per_tick);  /*  LSB=1ns  */

    return TRUE;
#else
#if (SAB_DEV_ERROR_DETECT == STD_ON)
    Det_ReportError(SAB_MODULE_ID, 0, SAB_LOWLEVEL_TIMER_API, SAB_E_NO_SERVICE);
#endif
    return FALSE;
#endif /* SAB_ONE_NANOSECONDPRECISION == STD_ON */

}

#endif /* SAB_GPT_STUB_C */

/*------------------------------------------------------------------------------------------------*\
  END OF FILE
\*------------------------------------------------------------------------------------------------*/
