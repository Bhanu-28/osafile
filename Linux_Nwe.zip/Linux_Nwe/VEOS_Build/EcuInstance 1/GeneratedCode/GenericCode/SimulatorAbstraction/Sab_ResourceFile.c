/**************************************************************************************************\
 *** Sab_ResourceFile.c
 ***
 *** Implementation the GetResourceFullPathName() for VEOS using the Windows API.
 ***
 *** Copyright 2021 by dSPACE GmbH, Paderborn, Germany.
 *** All Rights Reserved.
\**************************************************************************************************/

#ifndef SAB_RESOURCE_FILE_C
#define SAB_RESOURCE_FILE_C

/*------------------------------------------------------------------------------------------------*\
  INCLUDES
\*------------------------------------------------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include <limits.h>

/*------------------------------------------------------------------------------------------------*\
  PARAMETRIZED MACROS
\*------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------*\
  VARIABLE DECLARATIONS
\*------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------*\
  FUNCTION DEFINITIONS
\*------------------------------------------------------------------------------------------------*/


/**************************************************************************************************\
 *** FUNCTION:
 ***     Sab_GetResourceLocationFullPathName
 ***
 *** DESCRIPTION:
 ***     Returns the root directory on the target platform where the resource files of the V-ECU are stored. 
 ***
 *** PARAMETERS:
 ***     Type           Name               Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     
 ***
 *** RETURNS:
 ***     char*   The root directory where the resource files of the V-ECU application process are located.
 \**************************************************************************************************/
char* Sab_GetResourceLocationFullPathName(void)
{
    static char resourcePath[PATH_MAX];

    if (realpath(".", resourcePath) == NULL)
    {
        return NULL;
    }
    return resourcePath;
}


#endif /* SAB_RESOURCE_FILE_C */

/*------------------------------------------------------------------------------------------------*\
  END OF FILE
\*------------------------------------------------------------------------------------------------*/
