/**************************************************************************************************\
 *** Os_Counter.c
 ***
 *** OSEK API function definition for OS Counters.
 ***
 *** Copyright (c) 2014 by dSPACE GmbH, Paderborn, Germany.
 *** All Rights Reserved.
\**************************************************************************************************/

#ifndef OS_COUNTER_C
#define OS_COUNTER_C
    
/*------------------------------------------------------------------------------------------------*\
  INCLUDES
\*------------------------------------------------------------------------------------------------*/

#include "Os_Alarm.h"
#include "Os_SchedTbl.h"
#include "Os_Counter.h"

#include "Os_Kernel.h"
#include "Os_InternalTypes.h"
#include "Os_Cfg.h"
#include "Os_SimulationCore.h"

/*------------------------------------------------------------------------------------------------*\
  FUNCTION DEFINITIONS
\*------------------------------------------------------------------------------------------------*/

#if NUMBER_OF_COUNTERS > 0


StatusType Os_InitCounter(CounterType CounterID, TickType Ticks)
{
    OS_ErrorInfo.ServiceId = OSServiceId_InitCounter;

    if(CounterID >= NUMBER_OF_COUNTERS)
    {
        ERRORHOOK(E_OS_ID);
        return E_OS_ID;
    }

    if (0 == g_CtrCb[CounterID].MaxAllowedValue)
    {
        ERRORHOOK(E_OS_SYS_INTERNAL);
        return E_OS_SYS_INTERNAL;
    }

    if(Ticks > g_CtrCb[CounterID].MaxAllowedValue)
    {
        ERRORHOOK(E_OS_VALUE);
        return E_OS_VALUE;
    }

    if(Ticks == (TickType)0)
    {
        Ticks = (TickType)-1;
    }

    g_CtrCb[CounterID].CtrValue = Ticks;

    return E_OK;
}

/**************************************************************************************************\
 *** FUNCTION:
 ***     TimerEventCounterTrigger
 ***
 *** DESCRIPTION:
 ***    Trigger the counter with ID CounterID. If the counter drives an alarm or schedule table the function
 ***    will activate the tasks or set events of these alarms or schedule tables.
 ***
 ***
 *** PARAMETERS:
 ***     Type             Name     Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     CounterType      CounterID The ID of the counter
 ***
 ***
 *** RETURNS:
 ***     StatusType
\**************************************************************************************************/
StatusType Os_TimerEventCounterTrigger(CounterType CounterID)
{
    StatusType returnValue = E_NOT_OK;

    OS_ErrorInfo.ServiceId = OSServiceId_CounterTrigger;

    if (CounterID >= NUMBER_OF_COUNTERS)
    {
        ERRORHOOK(E_OS_ID);
        return E_OS_ID;
    }

    returnValue = Os_CounterTriggerDeltaTime(CounterID);

    if (g_CtrCb[CounterID].CounterType == OS_COUNTER_HARDWARE)
    {

#if NUMBER_OF_ALARMS > 0

   /* If the counter drives an alarm 'Os_AlarmHandler()' will activate the tasks or set events of these alarms. */
   returnValue = Os_AlarmHandler(CounterID);

#endif /* NUMBER_OF_ALARMS > 0 */

#if NUMBER_OF_SCHEDULE_TABLES > 0

   /* If the counter drives a schedule table 'Os_ScheduleTableHandler()' will activate the tasks or set events of these schedule table. */
   returnValue = Os_ScheduleTableHandler(CounterID);

#endif
    }    
    return returnValue;
}

/**************************************************************************************************\
 *** FUNCTION:
 ***     CounterTriggerDeltaTime
 ***
 *** DESCRIPTION:
 ***    Trigger the counter with ID CounterID and the simTime. Calcutate den delta time.
 ***
 ***
 *** PARAMETERS:
 ***     Type             Name     Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     CounterType      CounterID The ID of the counter
 ***
 ***
 *** RETURNS:
 ***     StatusType
\**************************************************************************************************/
StatusType Os_CounterTriggerDeltaTime(CounterType CounterID)
{
    
    StatusType returnValue = E_OK;

    OS_ErrorInfo.ServiceId = OSServiceId_CounterTrigger;

    if (CounterID >= NUMBER_OF_COUNTERS)
    {
        ERRORHOOK(E_OS_ID);
        return E_OS_ID;
    }

    /* no need to adjust alarms anymore after first counter trigger,
       because first counter trigger will step system time from -1 to 0 */
    if (OS_FALSE == g_CtrCb[CounterID].IsInitialized)
    {
        g_CtrCb[CounterID].IsInitialized = OS_TRUE;
        g_CtrCb[CounterID].CtrValue = (TickType)0;
    }
    else
    {
        if (g_CtrCb[CounterID].CounterType == OS_COUNTER_HARDWARE)
        {
            TickType deltaCounter = (TickType)((g_Kernel.SimTime - g_CtrCb[CounterID].LastSimTime) / g_CtrCb[CounterID].MultipleOfSimTimeBase);
            if ((g_CtrCb[CounterID].CtrValue + deltaCounter) > g_CtrCb[CounterID].MaxAllowedValue)
            {
               g_CtrCb[CounterID].CtrValue = (TickType)(g_CtrCb[CounterID].CtrValue + deltaCounter - g_CtrCb[CounterID].MaxAllowedValue - 1);
            }
            else
            {
                g_CtrCb[CounterID].CtrValue += deltaCounter;
            }
        }        
    }
    if (g_CtrCb[CounterID].CounterType == OS_COUNTER_HARDWARE)
    {
        g_CtrCb[CounterID].LastSimTime = g_Kernel.SimTime - (TickType)((g_Kernel.SimTime - g_CtrCb[CounterID].LastSimTime) % g_CtrCb[CounterID].MultipleOfSimTimeBase);
    }    
    return returnValue;
}



/**************************************************************************************************\
 *** FUNCTION:
 ***     Os_CounterTriggerSolely
 ***
 *** DESCRIPTION:
 ***    Trigger the counter with ID CounterID. If the counter drives an alarm or schedule table the function
 ***    will activate the tasks or set events of these alarms or schedule tables.
 ***
 ***
 *** PARAMETERS:
 ***     Type             Name     Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     CounterType      CounterID The ID of the counter
 ***
 ***
 *** RETURNS:
 ***     StatusType
\**************************************************************************************************/
StatusType Os_CounterTriggerSolely(CounterType CounterID)
{
    StatusType returnValue = E_OK;

    OS_ErrorInfo.ServiceId = OSServiceId_CounterTrigger;

    if (CounterID >= NUMBER_OF_COUNTERS)
    {
        ERRORHOOK(E_OS_ID);
        return E_OS_ID;
    }

    if (OS_FALSE == g_CtrCb[CounterID].IsInitialized)
    {
        g_CtrCb[CounterID].IsInitialized = OS_TRUE;
    }

    g_CtrCb[CounterID].LastSimTime++;
    if (g_CtrCb[CounterID].CtrValue == g_CtrCb[CounterID].MaxAllowedValue)
    {
        g_CtrCb[CounterID].CtrValue = (TickType)0u;
    }
    else
    {
        g_CtrCb[CounterID].CtrValue++;
    }

#if NUMBER_OF_ALARMS > 0

   /* If the counter drives an alarm 'Os_AlarmHandler()' will activate the tasks or set events of these alarms. */
   returnValue = Os_AlarmHandler(CounterID);

#endif /* NUMBER_OF_ALARMS > 0 */

#if NUMBER_OF_SCHEDULE_TABLES > 0

   /* If the counter drives a schedule table 'Os_ScheduleTableHandler()' will activate the tasks or set events of these schedule table. */
   returnValue = Os_ScheduleTableHandler(CounterID);

#endif

    return returnValue;
}

/**************************************************************************************************\
 *** FUNCTION:
 ***     GetCounterValue
 ***
 *** DESCRIPTION:
 ***    Get for a counter with ID 'CounterID' the counter value
 ***
 *** PARAMETERS:
 ***     Type             Name     Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     CounterType      CounterID    Id of the counter
 ***     TickRefType      TicksRef     Value of the counter
 ***
 *** RETURNS:
 ***     StatusType
\**************************************************************************************************/
StatusType GetCounterValue(CounterType CounterID, TickRefType TicksRef)
{
    OS_ErrorInfo.ServiceId = OSServiceId_GetCounterValue1;
    OS_ErrorInfo.ServiceParameterInfo.GetCounterValue.CounterID = CounterID;

    if(CounterID >= NUMBER_OF_COUNTERS)
    {
        ERRORHOOK(E_OS_ID);
        return E_OS_ID;
    }

    *TicksRef = g_CtrCb[CounterID].CtrValue;

    return E_OK;
}

/**************************************************************************************************\
 *** FUNCTION:
 ***     GetElapsedCounterValue
 ***
 *** DESCRIPTION:
 ***    Get for a counter with the ID 'CounterID' the elapsed counter value
 ***
 *** PARAMETERS:
 ***     Type             Name     Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     CounterType      CounterID     Id of the counter
 ***     TickRefType      Value         Value of the counter
 ***     TickRefType      ElapsedValue  Value of the counter
 ***
 *** RETURNS:
 ***     StatusType
\**************************************************************************************************/
StatusType GetElapsedCounterValue(CounterType CounterID, TickRefType Value, TickRefType ElapsedValue)
{
    TickType lValue;

    OS_ErrorInfo.ServiceId = OSServiceId_GetElapsedValue;
    OS_ErrorInfo.ServiceParameterInfo.GetElapsedValue.CounterID = CounterID;
    OS_ErrorInfo.ServiceParameterInfo.GetElapsedValue.Value = *Value;

    if (CounterID > NUMBER_OF_COUNTERS)
    {
        ERRORHOOK(E_OS_ID);
        return E_OS_ID;
    }

    if (OS_NULL == Value)
    {
        ERRORHOOK(E_OS_ILLEGAL_ADDRESS);
        return E_OS_ILLEGAL_ADDRESS;
    }

    if (OS_NULL == ElapsedValue)
    {
        ERRORHOOK(E_OS_ILLEGAL_ADDRESS);
        return E_OS_ILLEGAL_ADDRESS;
    }

    lValue = *(Value);
    if (lValue > g_CtrCb[CounterID].MaxAllowedValue)
    {
        ERRORHOOK(E_OS_VALUE);
        return E_OS_VALUE;
    }

    lValue = lValue + g_CtrCb[CounterID].CtrValue;
    lValue = lValue % g_CtrCb[CounterID].MaxAllowedValue;

    *(ElapsedValue) = lValue;

    return E_OK;
}


/**************************************************************************************************\
 *** FUNCTION:
 ***     IncrementCounter
 ***
 *** DESCRIPTION:
 ***    IncrementCounter() shall increment the counter <CounterID> by one (if any alarm connected
 ***    to this counter expires, the given action, e.g. task activation, is done) and shall return E_OK.
 ***
 *** PARAMETERS:
 ***     Type             Name     Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ***     CounterType      CounterID    Id of the counter
 ***
 *** RETURNS:
 ***     StatusType
\**************************************************************************************************/
StatusType IncrementCounter(CounterType CounterID)
{
#ifdef OS_DBGMSG_ENABLED
    Os_SimulationCoreLogDbgMessage(__FUNCTION__, "IncrementCounter(): Start of function. Counter ID is %d.", CounterID);
#endif

    OS_ErrorInfo.ServiceId = OSServiceId_IncrementCounter;
    OS_ErrorInfo.ServiceParameterInfo.IncrementCounter.CounterId = CounterID;

    if( CounterID >= NUMBER_OF_COUNTERS)
    {
        ERRORHOOK(E_OS_ID);
        return E_OS_ID;
    }

    if (g_CtrCb[CounterID].CounterType == OS_COUNTER_HARDWARE)
    {
        ERRORHOOK(E_OS_VALUE);
        return E_OS_VALUE;
    }

    Os_CounterTriggerSolely(CounterID);

    return E_OK;
}

#endif /* NUMBER_OF_COUNTERS > 0 */

#endif /* OS_COUNTER_C */

/*------------------------------------------------------------------------------------------------*\
  END OF FILE
\*------------------------------------------------------------------------------------------------*/
