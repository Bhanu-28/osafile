/**************************************************************************************************\
 *** Os_ErrorHandler.h
 ***
 *** Definitions for OSEK error hook function.
 ***
 *** Copyright (c) 2009 by dSPACE GmbH, Paderborn, Germany.
 *** All Rights Reserved.
\**************************************************************************************************/

#ifndef OS_ERROR_HANDLER_H
#define OS_ERROR_HANDLER_H

/*------------------------------------------------------------------------------------------------*\
  INCLUDES
\*------------------------------------------------------------------------------------------------*/

#include "Os_InternalTypes.h"

/*------------------------------------------------------------------------------------------------*\
  DEFINES
\*------------------------------------------------------------------------------------------------*/

#ifdef OS_DBGMSG_ENABLED
#undef OS_DBGMSG_ENABLED
#endif

#ifdef VEOS_DEBUG
#define OS_DBGMSG_ENABLED
#else
#define Os_SimulationCoreLogDbgMessage                            (void)0
#endif



/*-------- Only for VEOS ---------*/
#define E_OS_SYS_INTERNAL (E_OS_PARAM_POINTER + 1) 

#define OSServiceId_EnterISR (OSServiceId_ShutdownAllCores + 1)
#define OSServiceId_LeaveISR (OSServiceId_ShutdownAllCores + 2)
#define OSServiceId_EnableInterrupt (OSServiceId_ShutdownAllCores + 3)
#define OSServiceId_DisableInterrupt (OSServiceId_ShutdownAllCores + 4)
#define OSServiceId_GetInterruptDescriptor (OSServiceId_ShutdownAllCores + 5)
#define OSServiceId_SendMessage (OSServiceId_ShutdownAllCores + 6)
#define OSServiceId_ReceiveMessage (OSServiceId_ShutdownAllCores + 7)
#define OSServiceId_ActivateISR (OSServiceId_ShutdownAllCores + 8)
#define OSServiceId_InitCounter (OSServiceId_ShutdownAllCores + 9)
#define OSServiceId_CounterTrigger (OSServiceId_ShutdownAllCores + 10)
#define OSServiceId_GetCounterValue1 (OSServiceId_ShutdownAllCores + 11)
#define OSServiceId_GetCounterValue2 (OSServiceId_ShutdownAllCores + 12)
#define OSServiceId_XPeripheral (OSServiceId_ShutdownAllCores + 13)
#define OSServiceId_CheckXMemoryAccess (OSServiceId_ShutdownAllCores + 14)
#define OSServiceId_CheckObjectOwnerShip (OSServiceId_ShutdownAllCores + 15)



/*------------------------------------------------------------------------------------------------*\
  TYPEDEFS
\*------------------------------------------------------------------------------------------------*/

typedef struct tagOsSErrorInfoType
{
    StatusType         Error;
} Os_SErrorInfoType;

/*------------------------------------------------------------------------------------------------*\
  FORWARD DECLARATIONS
\*------------------------------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

extern Os_SErrorInfoType g_ErrorInfo;

#ifdef __cplusplus
}
#endif

#endif /* OS_ERROR_HANDLER_H */
