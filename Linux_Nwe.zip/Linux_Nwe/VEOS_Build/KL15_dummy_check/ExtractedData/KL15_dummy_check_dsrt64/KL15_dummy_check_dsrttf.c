/*****************************************************************************

   Include file KL15_dummy_check_dsrttf.c:

   Definition of task functions.

   Thu Nov 30 16:04:45 2023

   Copyright 2019, dSPACE GmbH. All rights reserved.

 *****************************************************************************/

/* Include header files */
#include "KL15_dummy_check_dsrttf.h"
#include "KL15_dummy_check.h"
#include "KL15_dummy_check_private.h"

/* Task function for TID0 */
void KL15_dummy_check_DSRTMdlOutputs0()
{
  /* Call to Simulink model output function */
  KL15_dummy_check_output();
}

void KL15_dummy_check_DSRTMdlUpdate0()
{
  /* Call to Simulink model upadte function */
  KL15_dummy_check_update();
}
