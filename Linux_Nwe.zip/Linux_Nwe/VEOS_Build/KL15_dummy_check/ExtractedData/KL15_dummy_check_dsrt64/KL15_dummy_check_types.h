/*
 * KL15_dummy_check_types.h
 *
 * Code generation for model "KL15_dummy_check".
 *
 * Model version              : 1.11
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Thu Nov 30 16:04:45 2023
 *
 * Target selection: dsrt64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Custom Processor->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_KL15_dummy_check_types_h_
#define RTW_HEADER_KL15_dummy_check_types_h_

/* Model Code Variants */

/* Parameters (default storage) */
typedef struct P_KL15_dummy_check_T_ P_KL15_dummy_check_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_KL15_dummy_check_T RT_MODEL_KL15_dummy_check_T;

#endif                                /* RTW_HEADER_KL15_dummy_check_types_h_ */
