/*********************** dSPACE target specific header file ********************
   Include file KL15_dummy_check_dsmpbap.h:

   Definitions used for access points

   Thu Nov 30 16:04:45 2023

   (c) Copyright 2022, dSPACE GmbH. All rights reserved.

 *******************************************************************************/

#ifndef _DSMPB_KL15_dummy_check_HEADER_
#define _DSMPB_KL15_dummy_check_HEADER_
#include "rtwtypes.h"
#ifdef EXTERN_C
#undef EXTERN_C
#endif

#ifdef __cplusplus
#define EXTERN_C                       extern "C"
#else
#define EXTERN_C                       extern
#endif

/* External declarations for access points prototypes */

/*                                                                            */
/* Declarations of read/write and trigger access points                       */
/*                                                                            */
/* Write access point of block KL15_dummy_check/KL15, non-bus port 1 */
EXTERN_C void ap_write_KL15_dummy_check_DataOutport1_P1_S1(const real_T
  * InputPortSignalPtr);

/* Write access point of block KL15_dummy_check/Kl30, non-bus port 1 */
EXTERN_C void ap_write_KL15_dummy_check_DataOutport2_P1_S1(const real_T
  * InputPortSignalPtr);

/* Read access point of block KL15_dummy_check/KL_15_status, non-bus port 1 */
EXTERN_C void ap_read_KL15_dummy_check_DataInport1_P1_S1(real_T
  * OutputPortSignalPtr);

/*                                                                            */
/* Declarations of function module access points                              */
/*                                                                            */
/* Function module access point of system <Root>    */
EXTERN_C void ap_entry_KL15_dummy_check_SIDRoot_TID0();
EXTERN_C void ap_exit_KL15_dummy_check_SIDRoot_TID0();

#endif
