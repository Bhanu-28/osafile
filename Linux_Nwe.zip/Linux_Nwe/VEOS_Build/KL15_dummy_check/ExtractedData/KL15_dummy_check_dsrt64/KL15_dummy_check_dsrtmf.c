/*****************************************************************************

   Include file KL15_dummy_check_dsrtmf.c:

   Definition of model functions.

   Thu Nov 30 16:04:45 2023

   Copyright 2020, dSPACE GmbH. All rights reserved.

 *****************************************************************************/

/* Include the model header file. */
#include "KL15_dummy_check.h"
#include "KL15_dummy_check_private.h"
#include "KL15_dummy_check_dsrtmf.h"

/* Function KL15_dummy_check_dsrt_mdl_ApSimEngineOnInitIoPreRtosInit() is empty */

/* Function dsrt_mdl_timesync_simstate() is empty */

/* Function KL15_dummy_check_dsrt_mdl_ApSimEngineIdle() is empty */

/****** [EOF] ****************************************************************/
