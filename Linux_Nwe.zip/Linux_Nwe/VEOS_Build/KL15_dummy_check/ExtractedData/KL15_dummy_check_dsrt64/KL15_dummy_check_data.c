/*
 * KL15_dummy_check_data.c
 *
 * Code generation for model "KL15_dummy_check".
 *
 * Model version              : 1.11
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Thu Nov 30 16:04:45 2023
 *
 * Target selection: dsrt64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Custom Processor->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "KL15_dummy_check.h"

/* Block parameters (default storage) */
P_KL15_dummy_check_T KL15_dummy_check_P = {
  /* Expression: 1
   * Referenced by: '<Root>/KL15_Value'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/KL15_Value_Gain'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/KL30_Value'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/KL30_Value_Gain'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/KL_15_status_Gain'
   */
  1.0
};
