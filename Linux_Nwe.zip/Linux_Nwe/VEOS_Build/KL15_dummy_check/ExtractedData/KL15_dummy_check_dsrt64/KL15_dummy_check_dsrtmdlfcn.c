/**************************************************************************** *
 * FILE :
 *  KL15_dummy_check_dsrtmdlfcn.c
 *
 *
 *
 * Copyright 2017, dSPACE GmbH. All rights reserved
 *
   \****************************************************************************/

#ifndef TEMP_DSRT_RTI
#include <rtmodel.h>
#include "rtwtypes.h"
#include "KL15_dummy_check_dsrtmdlfcn.h"
#include <stdio.h>

int32_T DSRTStopSimulation = 0;
EXTERN_C_DECL void KL15_dummy_check_initialize();
EXTERN_C_DECL void KL15_dummy_check_terminate();

/* Initialization of model */
void KL15_dummy_check_DSRTInitMdl(void)
{
  /* Initialize model */
  KL15_dummy_check_initialize();

  /* Check for initialization errors */
  KL15_dummy_check_DSRTCheckForErrorStatus();

  /* Reinit Stop Simulation flag*/
  DSRTStopSimulation = 0;
}

/* Model start function */
void KL15_dummy_check_DSRTStartMdl(void)
{
  uint8_T lastApplStateStopped;
  KL15_dummy_check_APLastApplStateStopped(&lastApplStateStopped);
  if (lastApplStateStopped) {
    /* Reinit main simulation structure */
    KL15_dummy_check_DSRTInitMdl();
  }
}

/* Model stop function */
void KL15_dummy_check_DSRTStopMdl(void)
{
  /* Call terminate function */
  KL15_dummy_check_terminate();

  /* Check for model error status */
  KL15_dummy_check_DSRTCheckForErrorStatus();
}

/* Check for model error status */
void KL15_dummy_check_DSRTCheckForErrorStatus()
{
  const char_T* errorStatus = rtmGetErrorStatus(KL15_dummy_check_M);
  if (errorStatus != NULL && strcmp(errorStatus, "Simulation finished") == 0) {
    /* The RTM errorStatus field has been set */
    KL15_dummy_check_APTerminateSimulation();
    KL15_dummy_check_APPrintMessage("Model 'KL15_dummy_check' error status:");
    KL15_dummy_check_APPrintMessage(errorStatus);
  }
}

/* Check for simulation stop conditions */
void KL15_dummy_check_DSRTCheckForSimulationStopCondition(void)
{
  const char_T* errorStatus = rtmGetErrorStatus(KL15_dummy_check_M);
  if (errorStatus != NULL) {
    if (DSRTStopSimulation != 1) {
      /* The RTM errorStatus field was set */
      KL15_dummy_check_APTerminateSimulation();
      KL15_dummy_check_APPrintMessage("Model 'KL15_dummy_check' error status:");
      KL15_dummy_check_APPrintMessage(errorStatus);
      DSRTStopSimulation = 1;
    }
  } else if (rtmGetStopRequested(KL15_dummy_check_M)) {
    if (DSRTStopSimulation != 1) {
      KL15_dummy_check_APStopSimulation();
      KL15_dummy_check_APPrintMessage(
        "Model 'KL15_dummy_check': Executed a Simulink Stop Simulation block or request.");
      DSRTStopSimulation = 1;
    }
  }
}

#endif
