/*
 * KL15_dummy_check.c
 *
 * Code generation for model "KL15_dummy_check".
 *
 * Model version              : 1.11
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Thu Nov 30 16:04:45 2023
 *
 * Target selection: dsrt64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Custom Processor->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "KL15_dummy_check_dsrtvdf.h"
#include "KL15_dummy_check.h"

/* Block signals (default storage) */
B_KL15_dummy_check_T KL15_dummy_check_B;

/* Block states (default storage) */
DW_KL15_dummy_check_T KL15_dummy_check_DW;

/* Real-time model */
static RT_MODEL_KL15_dummy_check_T KL15_dummy_check_M_;
RT_MODEL_KL15_dummy_check_T *const KL15_dummy_check_M = &KL15_dummy_check_M_;

/* Model output function */
void KL15_dummy_check_output(void)
{
  /* user code (Output function Body) */
  {
    /* Function module access point of system <Root>    */
    ap_entry_KL15_dummy_check_SIDRoot_TID0();
  }

  /* Gain: '<Root>/KL15_Value_Gain' incorporates:
   *  Constant: '<Root>/KL15_Value'
   */
  KL15_dummy_check_B.KL15_Value_Gain = KL15_dummy_check_P.KL15_Value_Gain_Gain *
    KL15_dummy_check_P.KL15_Value_Value;

  /* S-Function (dsmpb_dataoutport): '<S1>/Data Outport S-Fcn' */

  /* Write access point of block KL15_dummy_check/KL15 non-bus port 1 */
  ap_write_KL15_dummy_check_DataOutport1_P1_S1
    (&KL15_dummy_check_B.KL15_Value_Gain);

  /* Gain: '<Root>/KL30_Value_Gain' incorporates:
   *  Constant: '<Root>/KL30_Value'
   */
  KL15_dummy_check_B.KL30_Value_Gain = KL15_dummy_check_P.KL30_Value_Gain_Gain *
    KL15_dummy_check_P.KL30_Value_Value;

  /* S-Function (dsmpb_dataoutport): '<S3>/Data Outport S-Fcn' */

  /* Write access point of block KL15_dummy_check/Kl30 non-bus port 1 */
  ap_write_KL15_dummy_check_DataOutport2_P1_S1
    (&KL15_dummy_check_B.KL30_Value_Gain);

  /* S-Function (dsmpb_datainport): '<S2>/Data Inport S-Fcn' */

  /* Read access point of block KL15_dummy_check/KL_15_status non-bus port 1 */
  ap_read_KL15_dummy_check_DataInport1_P1_S1(&KL15_dummy_check_B.Kl15_status);

  /* Gain: '<Root>/KL_15_status_Gain' */
  KL15_dummy_check_B.KL_15_status_Gain =
    KL15_dummy_check_P.KL_15_status_Gain_Gain * KL15_dummy_check_B.Kl15_status;

  /* user code (Output function Trailer) */
  {
    /* Function module access point of system <Root>    */
    ap_exit_KL15_dummy_check_SIDRoot_TID0();
  }
}

/* Model update function */
void KL15_dummy_check_update(void)
{
  /* (no update code required) */
}

/* Model initialize function */
void KL15_dummy_check_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)KL15_dummy_check_M, 0,
                sizeof(RT_MODEL_KL15_dummy_check_T));

  /* block I/O */
  (void) memset(((void *) &KL15_dummy_check_B), 0,
                sizeof(B_KL15_dummy_check_T));

  /* states (dwork) */
  (void) memset((void *)&KL15_dummy_check_DW, 0,
                sizeof(DW_KL15_dummy_check_T));

  {
    /* user code (registration function declaration) */
    /*Initialize global TRC pointers. */
    KL15_dummy_check_rti_init_trc_pointers();
  }

  /* Start for S-Function (dsmpb_datainport): '<S2>/Data Inport S-Fcn' */
  KL15_dummy_check_B.Kl15_status = 0;
}

/* Model terminate function */
void KL15_dummy_check_terminate(void)
{
  /* (no terminate code required) */
}
